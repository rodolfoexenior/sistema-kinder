

<?php $__env->startSection('title', 'Distribución'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Creando distribución</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::open(['route' => 'admin.coursemanagments.store']); ?>

                    <div class="form-group">
                        <?php echo Form::label('managment_id', 'Gestión'); ?>

                        <?php echo Form::select('managment_id', $managments, null, ['class' => 'form-control', 'placeholder' =>'Seleccione la gestión para asignar']); ?>

                        <?php $__errorArgs = ['managment_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('course_id', 'Curso'); ?>

                        <?php echo Form::select('course_id', $courses, null, ['class' => 'form-control', 'placeholder' =>'Seleccione el curso para asignar']); ?>

                        <?php $__errorArgs = ['course_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('teacher_id', 'Maestro'); ?>

                        <?php echo Form::select('teacher_id', $teachers, null, ['class' => 'form-control', 'placeholder' =>'Seleccione el maestro para asignar']); ?>

                        <?php $__errorArgs = ['teacher_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('turn_id', 'Turno'); ?>

                        <?php echo Form::select('turn_id', $turns, null, ['class' => 'form-control', 'placeholder' =>'Seleccione el turno para asignar']); ?>

                        <?php $__errorArgs = ['turn_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                            <?php echo Form::submit('Crear ciudad', ['class' =>'btn btn-primary btn-lg']); ?>

                   
                        
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-kinder\resources\views/admin/coursemanagments/create.blade.php ENDPATH**/ ?>