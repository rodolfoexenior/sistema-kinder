

<?php $__env->startSection('title', 'Tutores'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Listado de tutores</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if(session('info')): ?>
            <div class="alert alert-info">
                <strong><?php echo e(session('info')); ?></strong>
            </div>
        <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <a class="btn btn-success" href="<?php echo e(route('admin.tutors.create')); ?>">Crear nuevo tutor</a>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                            <th>Nombre</th>
                            <th>Paterno</th>
                            <th>Matetrno</th>
                            <th>Cédula</th>
                            <th>Teléfono</th>
                            <th colspan="2"></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tutors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tutor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tutor->nombres); ?></td>
                                    <td><?php echo e($tutor->paterno); ?></td>
                                    <td><?php echo e($tutor->materno); ?></td>
                                    <td><?php echo e($tutor->num_cedula); ?></td>
                                    <td><?php echo e($tutor->telefono); ?></td>
                                    <td width="10px">
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.tutors.edit',$tutor)); ?>">Editar</a>
                                    </td>
                                    <td width="10px">
                                        <form action="<?php echo e(route('admin.tutors.destroy',$tutor)); ?>" method="post">
                                            <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-kinder\resources\views/admin/tutors/index.blade.php ENDPATH**/ ?>