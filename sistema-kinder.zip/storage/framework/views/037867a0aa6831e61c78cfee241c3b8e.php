

<?php $__env->startSection('title', 'Turnos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Actualizar turno</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <?php if(session('info')): ?>
            <div class="alert alert-info">
                <strong><?php echo e(session('info')); ?></strong>
            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <?php echo Form::model($turn, ['route' => ['admin.turns.update', $turn], 'method' => 'put']); ?>

                    <div class="form-group">
                        <?php echo Form::label('nombre', 'Nombres'); ?>

                        <?php echo Form::text('nombre', null, ['class' => 'form-control', 'placeholder' =>'Ingrese nombre del turno o servicio']); ?>

                        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('descripcion', 'Descripción'); ?>

                        <?php echo Form::text('descripcion', null, ['class' => 'form-control', 'placeholder' =>'Ingrese la descripción del turno o servicio']); ?>

                        <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('precio', 'Precio/Mes'); ?>

                        <?php echo Form::text('precio', null, ['class' => 'form-control', 'placeholder' =>'Ingrese precio por mes']); ?>

                        <?php $__errorArgs = ['precio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('mes', 'Duración/Mes'); ?>

                        <?php echo Form::text('mes', null, ['class' => 'form-control', 'placeholder' =>'Ingrese la cantiad de meses de duración']); ?>

                        <?php $__errorArgs = ['mes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                        <?php echo Form::submit('Actualizar país', ['class' =>'btn btn-primary btn-lg']); ?>

               
                    
                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-kinder\resources\views/admin/turns/edit.blade.php ENDPATH**/ ?>