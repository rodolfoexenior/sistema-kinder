

<?php $__env->startSection('title', 'Distribución de cursos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Listado de cursos y sus designaciones</h1>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if(session('info')): ?>
            <div class="alert alert-info">
                <strong><?php echo e(session('info')); ?></strong>
            </div>
        <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <a class="btn btn-success" href="<?php echo e(route('admin.coursemanagments.create')); ?>">Crear nuevo y sus designaciones</a>
                </div>
                <div class="card-body">
                                     
                    <table class="table table-striped">
                        <thead>
                            <th>Gestion</th>
                            <th>Curso</th>
                            <th>Profesor</th>
                            <th>Turno</th>
                            <th colspan="2"></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $coursemanagments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coursemanagment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
                                <tr>
                                    <td><?php echo e($coursemanagment->managment->gestion); ?></td>
                                    <td><?php echo e($coursemanagment->course->nombre); ?></td>
                                    <td><?php echo e($coursemanagment->teacher->nombres); ?></td>
                                    <td><?php echo e($coursemanagment->turn->nombre); ?></td>
                                    <td width="10px">
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.coursemanagments.edit',$coursemanagment)); ?>">Editar</a>
                                    </td>
                                    <td width="10px">
                                        <form action="<?php echo e(route('admin.coursemanagments.destroy',$coursemanagment)); ?>" method="post">
                                            <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-kinder\resources\views/admin/coursemanagments/index.blade.php ENDPATH**/ ?>