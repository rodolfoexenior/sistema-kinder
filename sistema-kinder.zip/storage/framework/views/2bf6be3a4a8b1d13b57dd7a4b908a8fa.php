

<?php $__env->startSection('title', 'Turnos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Listado de turnos o servicios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <?php if(session('info')): ?>
            <div class="alert alert-info">
                <strong><?php echo e(session('info')); ?></strong>
            </div>
        <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <a class="btn btn-success" href="<?php echo e(route('admin.turns.create')); ?>">Crear turno o servicio</a>
                </div>
                <div class="card-body">
                    
                    <table class="table table-striped">
                        <thead>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Precio/mes</th>
                            <th>Duración/Mes</th>
                            <th colspan="2"></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $turns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $turn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($turn->nombre); ?>

                                    </td>
                                    <td>
                                        <?php echo e($turn->descripcion); ?>

                                    </td>
                                    <td>
                                        <?php echo e($turn->precio); ?>

                                    </td>
                                    <td>
                                        <?php echo e($turn->mes); ?>

                                    </td>
                                    <td width="10px">
                                        <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.turns.edit',$turn)); ?>">Editar</a>
                                    </td>
                                    <td width="10px">
                                        <form action="<?php echo e(route('admin.turns.destroy',$turn)); ?>" method="post">
                                            <?php echo csrf_field(); ?> <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm">Borrar</button>
                                        </form>
                                    </td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-kinder\resources\views/admin/turns/index.blade.php ENDPATH**/ ?>