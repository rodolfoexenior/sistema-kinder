

<?php $__env->startSection('title', 'Paises'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Crear gestión</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php echo Form::open(['route' => 'admin.yearbooks.store']); ?>

                        <div class="form-group">
                            <?php echo Form::label('gestion', 'Gestión'); ?>

                            <?php echo Form::text('gestion', null, ['class' => 'form-control', 'placeholder' =>'Registre la gesitón']); ?>

                            <?php $__errorArgs = ['gestion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
 
                            <?php echo Form::submit('Crear gestión', ['class' =>'btn btn-primary btn-lg']); ?>

                   
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistema-kinder\resources\views/admin/yearbooks/create.blade.php ENDPATH**/ ?>